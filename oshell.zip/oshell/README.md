OShell – Simplified Unix Shell

Compilation:
make

Execution:
./oshell
./oshell commands.txt

