#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "parser.h"
#include "errors.h"

// Split a line into commands and operators
int parse_line(char *line, command_t **cmds, int *count) {
    if (!line || !cmds || !count)
        return -1;

    *count = 0;
    *cmds = malloc(MAX_COMMANDS * sizeof(command_t));
    if (!*cmds) { print_error(); return -1; }

    // Remove comment
    char *comment = strchr(line, '#');
    if (comment) *comment = '\0';

    char *ptr = line;
    while (*ptr) {
        while (isspace(*ptr)) ptr++;
        if (!*ptr) break;

        command_t *cmd = &(*cmds)[*count];
        cmd->argv = malloc((MAX_ARGS + 1) * sizeof(char *));
        cmd->redirect = NULL;
        cmd->background = 0;
        cmd->pipe_out = 0;
        cmd->op = OP_NONE;

        int argc = 0;

        // Tokenize respecting >, &&, ||, ;, &, |
        while (*ptr && !strchr(";|&", *ptr)) {
            while (isspace(*ptr)) ptr++;
            if (!*ptr) break;

            char token[256] = {0};
            int tlen = 0;

            // Handle > operator inline
            if (*ptr == '>') {
                ptr++;
                while (isspace(*ptr)) ptr++;
                char filename[256];
                int flen = 0;
                while (*ptr && !isspace(*ptr) && *ptr != '>' && *ptr != '&' &&
                       *ptr != '|' && *ptr != ';') {
                    filename[flen++] = *ptr;
                    ptr++;
                }
                filename[flen] = '\0';
                if (flen == 0) { print_error(); return -1; }
                cmd->redirect = strdup(filename);
                continue;
            }

            // Handle normal token
            while (*ptr && !isspace(*ptr) && !strchr(";|&", *ptr)) {
                if (*ptr == '>') break; // handled separately
                token[tlen++] = *ptr;
                ptr++;
            }
            token[tlen] = '\0';
            if (tlen > 0) cmd->argv[argc++] = strdup(token);
        }

        cmd->argv[argc] = NULL;

        // Check operator after command
        while (*ptr && isspace(*ptr)) ptr++;
        if (*ptr) {
            if (*ptr == ';') cmd->op = OP_SEQ;
            else if (*ptr == '&') cmd->background = 1;
            else if (*ptr == '|') cmd->pipe_out = 1;
            // handle &&, || if needed by looking ahead
            if (*ptr == '&' && *(ptr + 1) == '&') { cmd->op = OP_AND; ptr++; }
            if (*ptr == '|' && *(ptr + 1) == '|') { cmd->op = OP_OR; ptr++; }
            ptr++;
        }

        (*count)++;
        if (*count >= MAX_COMMANDS) break;
    }

    return 0;
}

void free_commands(command_t *cmds, int count) {
    if (!cmds) return;
    for (int i = 0; i < count; i++) {
        if (cmds[i].argv) {
            for (int j = 0; cmds[i].argv[j]; j++)
                free(cmds[i].argv[j]);
            free(cmds[i].argv);
        }
        if (cmds[i].redirect) free(cmds[i].redirect);
    }
    free(cmds);
}

