#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "oshell.h"
#include "input.h"
#include "errors.h"
#include "parser.h"
#include "execute.h"

int last_status = 0;

int main(int argc, char *argv[])
{
    FILE *input = NULL;

    // Handle 0 or 1 argument (stdin or batch file)
    handle_startup_args(argc, argv, &input);

    while (1) {
        // Show prompt only in interactive mode
        if (is_interactive())
            write(STDOUT_FILENO, "$ ", 2);

        // Read a line from input
        char *line = read_line(input);
        if (!line)
            break;  // EOF or Ctrl+D

        // Normalize whitespace
        normalize_whitespace(line);

        // Parse the line
        command_t *cmds = NULL;
        int count = 0;

        if (parse_line(line, &cmds, &count) == -1) {
            free(line);
            continue;  // skip invalid line
        }

        // Execute parsed commands (fork + exec + redirection + && / ||)
        execute_commands(cmds, count);

        // Free memory allocated by parser
        free_commands(cmds, count);

        // Free the original line buffer
        free(line);
    }

    return last_status;
}

